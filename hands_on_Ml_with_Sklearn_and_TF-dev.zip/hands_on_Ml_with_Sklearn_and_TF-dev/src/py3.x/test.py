#!/usr/bin/python
# coding: utf-8

'''
Created on 2018-04-08
Update  on 2018-04-08
Author: xxx
GitHub: https://github.com/apachecn/OReilly_Hands_On_Machine_Learning_with_Scikit_Learn_and_TensorFlow.git
'''

print("test")
